clear;clc;

original_image=double(imread('marbles.BMP'));

%imshow(uint8(original_image))

[x,y,z]=size(original_image);


R_original=original_image(:,:,1);
G_original=original_image(:,:,2);
B_original=original_image(:,:,3);

N=8; % 8x8 blocks
            
row_block_number=floor(x/N);
column_block_number=double(floor(y/N));

original_blocks=cell(row_block_number,column_block_number,3); %cell to keep the 8x8 blocks of original image
quantized_blocks=cell(row_block_number,column_block_number,3);  %cell to keep the 8x8 blocks of quantized image

Q_50=[16 11 10 16 24 40 51 61;  %50-quantizer matrix
                  12 12 14 19 26 58 60 55;
                  14 13 16 24 40 57 69 56;
                  14 17 22 29 51 87 80 62;
                  18 22 37 56 68 109 103 77;
                  24 35 55 64 81 104 113 92;
                  49 64 78 87 103 121 120 101;                 
                  72 92 95 98 112 100 103 99];
              
%DCT and quantizing block by block             
for i=1:row_block_number   
    for j=1:column_block_number          
        original_blocks{i,j,1} = R_original((i-1)*N+1:i*N,(j-1)*N+1:j*N);
        original_blocks{i,j,2} = G_original((i-1)*N+1:i*N,(j-1)*N+1:j*N);
        original_blocks{i,j,3} = B_original((i-1)*N+1:i*N,(j-1)*N+1:j*N);
        quantized_blocks{i,j,1}=round(dct2(original_blocks{i,j,1})./Q_50);
        quantized_blocks{i,j,2}=round(dct2(original_blocks{i,j,2})./Q_50);
        quantized_blocks{i,j,3}=round(dct2(original_blocks{i,j,3})./Q_50);  
    end
end


%% creating zigzag matrix
lower_half=[];

for i=2:N+1
    for j=1:i-1
        if mod(i,2)==1
            lower_half=[lower_half;j i-j];
        else
            lower_half=[lower_half;i-j j];
        end
    end
end
lower_freqs=(N+1)-lower_half(1:end-N,:);
higher_freqs=lower_freqs(end:-1:1,:);
zigzag_matrix=[lower_half;higher_freqs];

%% ENCODING AND DECODING %%%%%%%%%%%%%%% !!!!!!!!???????


[bit_r,bit_g,bit_b]= Huffman_encoding(quantized_blocks,N,zigzag_matrix);



%%

total_bits=max(size(bit_r))+max(size(bit_g))+max(size(bit_b));
compressed_size_byte=total_bits/8;


%%

reversed_blocks=cell(row_block_number,column_block_number,3);

for i=1:row_block_number   
    for j=1:column_block_number          
        reversed_blocks{i,j,1}=idct2(quantized_blocks{i,j,1}.*Q_50);
        reversed_blocks{i,j,2}=idct2(quantized_blocks{i,j,2}.*Q_50);
        reversed_blocks{i,j,3}=idct2(quantized_blocks{i,j,3}.*Q_50);
    end
end



%%
[xx,yy,zz]=size(reversed_blocks);

decompressed_image_R=[];
decompressed_image_G=[];
decompressed_image_B=[];


% building up the decompressed image back from the blocks
for i=1:xx
    decompressed_rows_R=[];
    decompressed_rows_G=[];
    decompressed_rows_B=[];
    for j=1:yy
        decompressed_rows_R=[decompressed_rows_R, reversed_blocks{i,j,1}]; 
        decompressed_rows_G=[decompressed_rows_G, reversed_blocks{i,j,2}]; 
        decompressed_rows_B=[decompressed_rows_B, reversed_blocks{i,j,3}]; 
  
    end  
    decompressed_image_R=[decompressed_image_R;decompressed_rows_R];
    decompressed_image_G=[decompressed_image_G;decompressed_rows_G];
    decompressed_image_B=[decompressed_image_B;decompressed_rows_B];

end

decompressed_image(:,:,1)=decompressed_image_R;
decompressed_image(:,:,2)=decompressed_image_G;
decompressed_image(:,:,3)=decompressed_image_B;



subplot(2,1,1);imshow(uint8(original_image));title('Original image');
subplot(2,1,2);imshow(uint8(decompressed_image));title('Decompressed image');
